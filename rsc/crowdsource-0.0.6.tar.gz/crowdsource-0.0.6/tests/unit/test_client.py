import pandas
import ujson
from datetime import datetime, timedelta
from sklearn.datasets import make_classification
from crowdsource.client import Client
from mock import patch, MagicMock
from crowdsource.competition import CompetitionSpec, CompetitionType, CompetitionMetric


dataset = make_classification()
competition = CompetitionSpec(type=CompetitionType.CLASSIFY,
                              expiration=datetime.now() + timedelta(minutes=1),
                              prize=1.0,
                              dataset=pandas.DataFrame(dataset[0]),
                              metric=CompetitionMetric.LOGLOSS,
                              answer=pandas.DataFrame(dataset[1]))


class TestClient:
    def setup(self):
        pass
        # setup() before each test method

    def teardown(self):
        pass
        # teardown() after each test method

    @classmethod
    def setup_class(cls):
        pass
        # setup_class() before any methods in this class

    @classmethod
    def teardown_class(cls):
        pass
        # teardown_class() after any methods in this class

    def test_init(self):
        c = Client('test')
        assert(c)

    def test_constructPath(self):
        c = Client('test')
        assert(c._constructPath('test') == 'test')

    def test_register(self):
        c = Client('test')

        with patch('requests.post'):
            c.register()
            assert(c._am_registered())

    def test_users(self):
        c = Client('test')
        with patch('requests.get') as mock:
            mock.return_value = MagicMock()
            mock.return_value.text = ujson.dumps({'test': 'test'})
            x = c.users()
            assert(x == {'test': 'test'})

    def test_start_competition(self):
        c = Client('test')
        with patch('requests.post') as mock:
            mock.return_value = MagicMock()
            mock.return_value.text = 'test'
            c.start_competition(competition)
            assert(c._my_competitions[0] == 'test')

    def test_compete(self):
        pass

    def test_sampleClassify(self):
        c = Client('test')
        with patch('requests.post') as mock:
            mock.return_value = MagicMock()
            mock.return_value.text = 'test'
            c._sampleClassify()
            assert(c._my_competitions[0] == 'test')

    def test_samplePredict1(self):
        c = Client('test')
        with patch('requests.post') as mock:
            mock.return_value = MagicMock()
            mock.return_value.text = 'test'
            c._samplePredict1()
            assert(c._my_competitions[0] == 'test')

    def test_samplePredict2(self):
        c = Client('test')
        with patch('requests.post') as mock:
            mock.return_value = MagicMock()
            mock.return_value.text = 'test'
            c._samplePredict2()
            assert(c._my_competitions[0] == 'test')

    def leaderboards(self):
        c = Client('test')
        with patch('requests.get') as mock:
            mock.return_value = MagicMock()
            mock.return_value.text = 'test'
            assert(c.leaderboards() == 'test')

    def test_submit(self):
        c = Client('test')
        with patch('requests.post') as mock:
            mock.return_value = MagicMock()
            mock.return_value.text = 'test'
            assert(c.submit(MagicMock(), MagicMock()) == 'test')
