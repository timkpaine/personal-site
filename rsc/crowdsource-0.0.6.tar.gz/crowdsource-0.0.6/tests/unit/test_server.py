from crowdsource.server import _genrand, ServerHandler, ServerClientRegisterHandler, ServerCompetitionRegistryHandler, ServerCompetitionSubmissionHandler, ServerAssetsHandler, ServerApplication
from crowdsource.login import null_login
from crowdsource.submit import null_submit
from crowdsource.persist import null_persist
from crowdsource.register import null_register
from mock import patch, MagicMock


class TestServer:
    def setup(self):
        pass
        # setup() before each test method

    def teardown(self):
        pass
        # teardown() after each test method

    @classmethod
    def setup_class(cls):
        pass
        # setup_class() before any methods in this class

    @classmethod
    def teardown_class(cls):
        pass
        # teardown_class() after any methods in this class

    def test_genrand(self):
        x = _genrand([], 10)
        assert(x in list(range(11)))
        x = _genrand([0, 1, 2, 3], 4)
        assert(x == 4)

    def test_ServerHandler(self):
        x = ServerHandler(MagicMock(), MagicMock())
        print(dir(x))
        x._set_401('test')
        assert(x.get_status() == 401)
        x._writeout('test', 'test')

    def test_ServerClientRegistrationHandler(self):
        req = MagicMock()
        req.body = ''
        x = ServerClientRegisterHandler(MagicMock(), req, clients={}, login=null_login, persist=null_persist)
        x.get()

        # initial registration
        x.post()

        # fixed id
        req.body = '{"id":1234}'
        x.post()
        x.get()

        # reregister
        x.post()

    def test_ServerCompetitionRegistryHandler(self):
        req = MagicMock()
        req.body = ''
        x = ServerCompetitionRegistryHandler(MagicMock(), req, clients={1234: ''}, competitions={}, active=set(), register=null_register, persist=null_persist)

        # requires client id
        x.get()
        x.post()
        assert(x.get_status() == 401)

        # malformed competition
        req.body = '{"id":1234}'
        x.post()
        assert(x.get_status() == 401)
        x.get()

    def test_ServerCompetitionSubmissionHandler(self):
        req = MagicMock()
        req.body = ''
        x = ServerCompetitionSubmissionHandler(MagicMock(), req, clients={1234: ''}, competitions={1234: ''}, active=set(), leaderboards={}, submit=null_submit, persist=null_persist)

        # requires client id
        x.get()
        x.post()
        assert(x.get_status() == 401)

        # unregistered
        req.body = '{"id":1233}'
        x.post()
        assert(x.get_status() == 401)

        # no competition id
        req.body = '{"id":1234}'
        x.post()
        assert(x.get_status() == 401)

        # no submission
        req.body = '{"id":1234, "competition_id":1234}'
        x.post()
        assert(x.get_status() == 401)

        # malformed submission
        req.body = '{"id":1234, "competition_id":1234, "submission": "{}"}'
        x.post()
        assert(x.get_status() == 401)

    def test_ServerAssetsHandler(self):
        req = MagicMock()
        req.body = ''
        x = ServerAssetsHandler(MagicMock(), req)
        x.get()
