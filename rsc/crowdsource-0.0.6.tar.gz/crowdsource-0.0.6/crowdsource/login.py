from .utils import _genrand


def null_login(client_data, *args, **kwargs):
    ids = [c.id for c in kwargs.get('clients').values()]
    return _genrand(ids)
