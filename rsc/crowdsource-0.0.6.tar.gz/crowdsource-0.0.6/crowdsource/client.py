import requests
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin
import ujson
import pandas
import threading
import time
from datetime import datetime, timedelta
from .competition import CompetitionSpec, CompetitionType, CompetitionMetric
from .logutils import LOG as log

# for sample
from sklearn.datasets import make_classification

# for predict
import cufflinks as cf


class Thread(threading.Thread):
    def __init__(self, target, competitionSpec, **kwargs):
        threading.Thread.__init__(self)
        self._mytarget = target
        self._kwargs = kwargs
        self._comp = competitionSpec

    def run(self):
        self._return = self._mytarget(self._comp, **self._kwargs)

    def join(self, timeout=.1):
        threading.Thread.join(self, timeout)

        if threading.Thread.isAlive(self):
            return None

        return self._return


class Client(object):
    def __init__(self, serverHost, id=None, passphrase=None):
        '''Constructor for client object

        Client is the primary API interface for
        communicating with the server

        Arguments:
            serverhost {str} -- IP/port of the competition server
            id {str} -- participant id (if known and registering on private server)
            passphrase {str} -- participant password (if applicable)
        '''
        self._host = serverHost

        if id:
            # Register right away
            self._id = int(requests.post(self._constructPath('register'), data=ujson.dumps({'id': id, 'passphrase': passphrase})).text)
        else:
            # Default to none, get after registering
            self._id = None

        self._callbacks = {}  # Callbacks by type
        self._competitions = {}  # Competitions I am competing in
        self._running = None  # Running competition thread

        self._my_competitions = []  # Competitions I am hosting

    def _constructPath(self, method):
        return urljoin(self._host, method)

    def register(self):
        '''Register client with the competitions host'''
        if not self._am_registered():
            resp = requests.post(self._constructPath('register'), data={})
            self._id = int(resp.text)
            return
        # attempt to re-register in case of disconnect
        requests.post(self._constructPath('register'), data=ujson.dumps({'id': self._id}))

    def _am_registered(self):
        return self._id is not None

    def users(self):
        '''Return a list of active user ids'''
        return ujson.loads(requests.get(self._constructPath('register')).text)

    def start_competition(self, competition):
        '''Host a competition

        Arguments:
            competition {CompetitionStruct} -- A competition struct
        '''
        if not isinstance(competition, CompetitionSpec):
            raise Exception('Competition must be an instance of CompetitionSpec')

        resp = requests.post(self._constructPath('competition'), data=ujson.dumps({'id': self._id, 'spec': competition.to_dict()}))
        self._my_competitions.append(resp.text)

    def competitions(self):
        '''Return a list of active competition ids'''
        return ujson.loads(requests.get(self._constructPath('competition')).text)

    def compete(self, competitionType, callback, **callbackArgs):
        '''Ping server for competitionId, on update call callback'''
        if not self._competitions.get(competitionType):
            self._competitions[competitionType] = []

        self._callbacks[competitionType] = self._callbacks[competitionType] + [callback] \
            if self._callbacks.get(competitionType) \
            else [callback]

        def ping_and_run():
            while(True):
                threads = {}
                competitions = self.competitions()
                for c in competitions:
                    id = c['id']
                    spec = c['spec']
                    for callback in self._callbacks.get(spec['type'], []):
                        if (id, callback) not in self._competitions[competitionType]:

                            # New competition or callback, run
                            t = Thread(target=callback, competitionSpec=CompetitionSpec.from_dict(spec), **callbackArgs)

                            # start thread
                            t.start()
                            threads[t] = (id, callback)

                            self._competitions[competitionType].append((id, callback))

                remove = []
                for t in threads:
                    # attempt to join
                    ret = t.join(.1)
                    if not t.isAlive():
                        # pop from thread list
                        id, _ = threads[t]
                        log.debug(self.submit(id, ret))
                        remove.append(t)

                for t in remove:
                    threads.pop(t)

                # ping every second
                time.sleep(2)

        if not self._running:
            t = threading.Thread(target=ping_and_run)
            t.start()
            self._running = True

    def _sampleClassify(self):
        dataset = make_classification()
        competition = CompetitionSpec(type=CompetitionType.CLASSIFY,
                                      expiration=datetime.now() + timedelta(minutes=1),
                                      prize=1.0,
                                      dataset=pandas.DataFrame(dataset[0]),
                                      metric=CompetitionMetric.LOGLOSS,
                                      answer=pandas.DataFrame(dataset[1]))
        resp = requests.post(self._constructPath('competition'), data=ujson.dumps({'id': self._id, 'spec': competition.to_dict()}))
        self._my_competitions.append(resp.text)

    def _samplePredict1(self):
        dataset = cf.datagen.ohlcv()
        competition = CompetitionSpec(type=CompetitionType.PREDICT,
                                      expiration=datetime.now() + timedelta(minutes=1),
                                      prize=1.0,
                                      dataset=dataset.iloc[:-1],
                                      metric=CompetitionMetric.ABSDIFF,
                                      target=dataset.columns[-1],
                                      answer=dataset.iloc[-1:],
                                      when=datetime.utcfromtimestamp(dataset[-1:].index.values[0].astype(datetime)/1000000000))
        resp = requests.post(self._constructPath('competition'), data=ujson.dumps({'id': self._id, 'spec': competition.to_dict()}))
        self._my_competitions.append(resp.text)

    def _samplePredict2(self):
        dataset = cf.datagen.lines()
        competition = CompetitionSpec(type=CompetitionType.PREDICT,
                                      expiration=datetime.now() + timedelta(minutes=1),
                                      prize=1.0,
                                      dataset=dataset.iloc[:-1],
                                      metric=CompetitionMetric.ABSDIFF,
                                      targets=[dataset.columns[1], dataset.columns[3]],
                                      answer=dataset.iloc[-1:],
                                      when=datetime.utcfromtimestamp(dataset[-1:].index.values[0].astype(datetime)/1000000000))
        resp = requests.post(self._constructPath('competition'), data=ujson.dumps({'id': self._id, 'spec': competition.to_dict()}))
        self._my_competitions.append(resp.text)

    def leaderboards(self, submissionId=None, clientId=None, competitionId=None, type=None):
        send = {}
        if submissionId:
            send['id'] = submissionId
        if clientId:
            send['client_id'] = clientId
        if competitionId:
            send['competition_id'] = competitionId
        if type:
            send['type'] = type
        return requests.get(self._constructPath('submission'), data=ujson.dumps(send)).text

    def submit(self, competitionId, submission):
        resp = requests.post(self._constructPath('submission'), data=ujson.dumps({'id': self._id, 'competition_id': competitionId, 'submission': submission.to_json()}))
        return resp.text
