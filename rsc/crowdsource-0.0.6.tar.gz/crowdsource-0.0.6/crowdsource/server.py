import sys
import os.path
import pandas
import tornado.ioloop
import tornado.web
import ujson
from .competition import checkAnswer, CompetitionType
from .login import null_login
from .logutils import LOG as log
from .persist import null_persist
from .register import null_register
from .structs import ClientStruct, CompetitionStruct, SubmissionStruct
from .submit import null_submit
from .utils import parse_args, _genrand, _parse_body
from .utils import _SKIP_REREGISTER, _REGISTER_KNOWN, _REGISTER_NEW, _REGISTER_COMPETITION, _CLIENT_NO_ID, _CLIENT_NOT_REGISTERED, _COMPETITION_NO_ID, _COMPETITION_NOT_REGISTERED, _COMPETITION_MALFORMED, _NO_SUBMISSION, _SUBMISSION_MALFORMED


class ServerHandler(tornado.web.RequestHandler):
    '''Just a default handler'''
    # def get(self):
    #     self.write("server")

    def _set_401(self, log_message, *args):
        log.info(log_message, *args)
        self.clear()
        self.set_status(401)

    def _writeout(self, message, log_message, *args):
        log.info(log_message, *args)
        self.set_header("Content-Type", "text/plain")
        self.write(message)


class ServerClientRegisterHandler(ServerHandler):
    def initialize(self, clients, login, persist):
        '''Initialize the server client registry handler

        This handler is responsible for managing client
        registration/authentication.

        Arguments:
            clients {dict} -- a reference to the server's dictionary of clients
        '''
        self._clients = clients
        self._login = login
        self._persist = persist

    def get(self):
        '''Get the current list of client ids'''
        self.write(ujson.dumps([c.to_dict() for c in self._clients.values()]))

    # @gen.coroutine
    def post(self):
        '''Register a client. Client will be assigned a session id'''
        # test = yield print('test')  # to understand coroutines
        data = _parse_body(self.request)

        log.info("New request from %s", data.get('id', 'ANON'))
        id = int(data.get('id', 0))

        # If they are already a client, skip, and return ID
        if id in self._clients:
            self._writeout(str(self._clients[id].id), _SKIP_REREGISTER, id)
            return

        if id:
            # known client registering
            self._clients[id] = ClientStruct(**data)
            self._writeout(str(id), _REGISTER_KNOWN, id)
            return

        # anonymous client, generate ID (if allowed)
        id = self._login(data, clients=self._clients)
        self._clients[id] = ClientStruct(id=id)
        self._persist(self._clients[id])
        self._writeout(str(id), _REGISTER_NEW, id)


class ServerCompetitionRegistryHandler(ServerHandler):
    def initialize(self, clients, competitions, active, register, persist):
        '''Initialize the server competition registry handler

        This handler is responsible for managing competition
        registration.

        Arguments:
            competitions {dict} -- a reference to the server's dictionary of competitions
        '''
        self._clients = clients
        self._competitions = competitions
        self._active = active
        self._register = register
        self._persist = persist

    def get(self):
        '''Get the current list of competition ids'''
        data = _parse_body(self.request)

        res = []
        for c in self._competitions.values():
            id = data.get('id', '')
            clid = data.get('client_id', '')
            t = data.get('type', '')
            if id and c.id not in id:
                continue
            if clid and c.clientId not in clid:
                continue
            if t and CompetitionType(t) not in c.spec.type:
                continue
            res.append(c.to_dict())
        self.write(ujson.dumps(res))

    # @gen.coroutine
    def post(self):
        '''Register a competition. Competition will be assigned a session id'''
        data = _parse_body(self.request)

        if not data.get('id'):
            self._set_401(_CLIENT_NO_ID)
            return

        if data.get('id') not in self._clients:
            self._set_401(_CLIENT_NOT_REGISTERED)
            return

        log.info("New request from %s", data.get('id'))

        # generate a new ID
        id = self._register(data, clients=self._clients, competitions=self._competitions, active=self._active)
        client_id = data.get('id')

        try:
            comp = CompetitionStruct(id=id, clientId=client_id, spec=data.get('spec'))
        except AttributeError:
            self._set_401(_COMPETITION_MALFORMED)
            return

        self._competitions[id] = comp
        self._active.add(id)
        self._persist(comp)
        self._writeout(str(id), _REGISTER_COMPETITION, id, client_id)


class ServerCompetitionSubmissionHandler(ServerHandler):
    def initialize(self, clients, competitions, active, leaderboards, submit, persist):
        '''Initialize the server competition registry handler

        This handler is responsible for managing competition
        registration.

        Arguments:
            competitions {dict} -- a reference to the server's dictionary of competitions
        '''
        self._clients = clients
        self._competitions = competitions
        self._active = active
        self._leaderboards = leaderboards
        self._submit = submit
        self._persist = persist

    def get(self):
        '''Get the current list of competition ids'''
        data = _parse_body(self.request)

        res = []
        for x in self._leaderboards.values():
            for c in x:
                id = data.get('id', '')
                cpid = data.get('competition_id', '')
                clid = data.get('client_id', '')
                t = data.get('type', '')
                if id and c.id not in id:
                    continue
                if cpid and c.competitionId not in cpid:
                    continue
                if clid and c.clientId not in clid:
                    continue
                if t and CompetitionType(t) not in c.competition.spec.type:
                    continue
                res.append(c.to_dict())
        self.write(ujson.dumps(res))

    # @gen.coroutine
    def post(self):
        '''Register a competition. Competition will be assigned a session id'''

        data = _parse_body(self.request)

        if not data.get('id'):
            self._set_401(_CLIENT_NO_ID)
            return

        if data.get('id') not in self._clients:
            self._set_401(_CLIENT_NOT_REGISTERED)
            return

        if not data.get('competition_id'):
            self._set_401(_COMPETITION_NO_ID)
            return

        if data.get('competition_id') not in self._active:
            self._set_401(_COMPETITION_NOT_REGISTERED)
            return

        if not data.get('submission'):
            self._set_401(_NO_SUBMISSION)
            return

        log.info("New submission from %s", data.get('id'))

        submission = data.get('submission')
        submission = pandas.DataFrame(ujson.loads(submission))

        # generate a new ID
        id = self._submit(data, clients=self._clients, competitions=self._competitions, active=self._active, leaderboard=self._leaderboards)

        # calculate result
        score = checkAnswer(self._competitions[data.get('competition_id')], submission)

        submission_struct = SubmissionStruct(id=id,
                                             clientId=data.get('id'),
                                             competitionId=data.get('competition_id'),
                                             competition=self._competitions[data.get('competition_id')],
                                             submission=submission,
                                             score=score)
        # update leaderboard
        if not self._leaderboards.get(data.get('competition_id')):
            self._leaderboards[data.get('competition_id')] = [submission_struct]
        else:
            self._leaderboards[data.get('competition_id')].append(submission_struct)

        self._persist(submission_struct)
        self.write(submission_struct.to_json())


class ServerAssetsHandler(ServerHandler):
    def get(self):
        pass


class ServerApplication(tornado.web.Application):
    def __init__(self, login, register, submit, persist, handlers, *args, **kwargs):
        self._login = login
        self._register = register
        self._submit = submit
        self._persist = persist

        self._clients = {}
        self._competitions = {}
        self._active = set()
        self._leaderboards = {}

        root = os.path.join(os.path.dirname(__file__), 'assets')

        default_handlers = [
            (r"/", ServerHandler),
            (r"/register", ServerClientRegisterHandler, {'clients': self._clients, 'login': self._login, 'persist': self._persist}),
            (r"/competition", ServerCompetitionRegistryHandler, {'clients': self._clients, 'competitions': self._competitions, 'active': self._active, 'register': self._register, 'persist': self._persist}),
            (r"/submission", ServerCompetitionSubmissionHandler, {'clients': self._clients, 'competitions': self._competitions, 'active': self._active, 'leaderboards': self._leaderboards, 'submit': self._submit, 'persist': self._persist}),
            (r"/(.*)", tornado.web.StaticFileHandler, {"path": root, "default_filename": "index.html"})

        ]
        for handler in handlers:
            default_handlers.append((handler[0], handler[1], {'clients': self._clients, 'competitions': self._competitions, 'active': self._active, 'leaderboards': self._leaderboards, 'login': self._login, 'register': self._register, 'submit': self._submit, 'server': self}))

        super(ServerApplication, self).__init__(default_handlers)


def main(*args, **kwargs):
    port = kwargs.get('port', 8889)
    login = kwargs.get('login', null_login)
    register = kwargs.get('register', null_register)
    submit = kwargs.get('submit', null_submit)
    persist = kwargs.get('persist', null_persist)

    handlers = kwargs.get('handlers', [])

    application = ServerApplication(login, register, submit, persist, handlers)
    log.info('Server listening on port: %s', port)
    application.listen(port)
    tornado.ioloop.IOLoop.current().start()


if __name__ == "__main__":
    args, kwargs = parse_args(sys.argv)
    main(*args, **kwargs)
