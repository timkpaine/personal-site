from .utils import _genrand


def null_submit(submission_data, *args, **kwargs):
    id = _genrand([c.id for c in kwargs.get('competitions').values()])
    return id
