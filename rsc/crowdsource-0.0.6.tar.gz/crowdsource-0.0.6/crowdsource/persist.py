def null_persist(*args, **kwargs):
    pass
