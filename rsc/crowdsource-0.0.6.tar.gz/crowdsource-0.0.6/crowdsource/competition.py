import pandas
import ujson
import time

from enum import Enum
from datetime import datetime
from sklearn.metrics import log_loss
from .utils import config


class CompetitionType(Enum):
    '''Enumeration of possible competitions

    Variables:
        PREDICT {str} -- Prediction competition
        CLASSIFY {str} -- Classification competition
    '''
    PREDICT = 'predict'
    CLASSIFY = 'classify'
    CLUSTER = 'cluster'


class CompetitionMetric(Enum):
    '''Enumeration of competition metrics

    Variables:
        LOGLOSS {str} -- log-loss
    '''
    LOGLOSS = 'logloss'
    ABSDIFF = 'absdiff'


@config
class CompetitionSpec(object):
    type = CompetitionType
    expiration = datetime

    prize = float

    dataset = pandas.DataFrame, pandas.DataFrame()
    dataset_url = str, ''

    metric = CompetitionMetric

    # For Classification
    num_classes = int, 2

    # For Prediction
    target = str, ''
    targets = list, []
    when = datetime, datetime.now()
    reference = pandas.DataFrame, pandas.DataFrame()

    # For Clustering

    # For All if answer is known
    answer = pandas.DataFrame, pandas.DataFrame()

    def to_dict(self):
        ret = {}
        for k in self._vars:
            val = getattr(self, k)
            if isinstance(val, CompetitionType):
                ret[k] = val.value
            elif isinstance(val, CompetitionMetric):
                ret[k] = val.value
            elif isinstance(val, dict):
                ret[k] = val['value']
            elif isinstance(val, pandas.DataFrame):
                ret[k] = val.to_json()
            elif isinstance(val, datetime):
                ret[k] = val.timestamp() if hasattr(val, 'timestamp') else float((time.mktime(val.timetuple())+val.microsecond/1000000.0))
            else:
                ret[k] = val
        return ret

    def to_json(self):
        return ujson.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, val):
        d = {}
        for k, v in val.items():
            if k == 'type':
                d[k] = CompetitionType(v)
            elif k == 'metric':
                d[k] = CompetitionMetric(v)
            elif k == 'dataset' or k == 'reference' or k == 'answer':
                if not v:
                    continue

                tmp = ujson.loads(v)

                if tmp:
                    d[k] = pandas.DataFrame(ujson.loads(v))
                else:
                    d[k] = pandas.DataFrame()

            elif k == 'expiration' or k == 'when':
                d[k] = datetime.fromtimestamp(v)
            else:
                d[k] = v
        return cls(**d)

    @classmethod
    def from_json(cls, json):
        val = ujson.loads(json)
        return CompetitionSpec.from_dict(val)

    @classmethod
    def validate(cls, competition):
        pass

    def __repr__(self):
        return '<type-' + str(self.type.value) + \
            'expiration-' + str(self.expiration) + \
            'prize-' + str(self.prize) + \
            'dataset-' + str(self.dataset.to_json()) + \
            'dataset_url-' + str(self.dataset_url) + \
            'metric-' + str(self.metric.value) + \
            'num_classes-' + str(self.num_classes) + \
            'target-' + str(self.target) + \
            'targets-' + str(self.targets) + \
            'reference-' + str(self.reference) + \
            '>'


def _metric(metric, x, y, **kwargs):
    if metric == CompetitionMetric.LOGLOSS:
        return log_loss(x, y, **kwargs)
    else:
        return (x.values-y.values).sum(1)[0]


def checkAnswer(compStruct, answer):
    spec = compStruct.spec
    if spec.type == CompetitionType.CLASSIFY:
        real_answer = compStruct.answer
        return _metric(compStruct.spec.metric, real_answer, answer, eps=1e-15)
    elif spec.type == CompetitionType.PREDICT:
        real_answer = compStruct.answer[spec.targets] if spec.targets else compStruct.answer[[spec.target]]
        return _metric(compStruct.spec.metric, real_answer, answer, eps=1e-15)
    elif spec.type == CompetitionType.CLUSTER:
        real_answer = compStruct.answer
        return _metric(compStruct.spec.metric, real_answer, answer, eps=1e-15)
    return 0.0
