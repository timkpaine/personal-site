import random
import tornado
from .logutils import LOG as log

_SKIP_REREGISTER = 'Skipping re-registration for client %s'
_REGISTER_KNOWN = 'Registering known client %s'
_REGISTER_NEW = 'Registering new client %s'
_REGISTER_COMPETITION = 'Registering competition %d from %s'
_CLIENT_NO_ID = 'Client did not provide id'
_CLIENT_NOT_REGISTERED = 'Client not registered'
_COMPETITION_NO_ID = 'Client did not provide competition id'
_COMPETITION_NOT_REGISTERED = 'Competition not registered/active'
_COMPETITION_MALFORMED = 'Client provided malformed competition'
_NO_SUBMISSION = 'Client provided no submission'
_SUBMISSION_MALFORMED = 'Client provided malformed submission'


def parse_args(argv):
    args = []
    kwargs = {}
    for arg in argv:
        if '--' not in arg and '-' not in arg:
            log.debug('ignoring argument: %s', arg)
            continue
        if '=' in arg:
            k, v = arg.replace('-', '').split('=')
            kwargs[k] = v
        else:
            args.append(arg.replace('-', ''))
    return args, kwargs


def create_pair(key, typ, default=None, container=None):
    def get(self):
        if hasattr(self, '__' + str(key)):
            return getattr(self, '__' + str(key))
        if default is not None and type(default) == typ:
            if container:
                if container == list:
                    return [default]
                else:
                    raise TypeError('Unrecognized container: %s',
                                    str(container))
            return default
        raise TypeError("%s is unset" % key)

    def set(self, val):
        if container:
            if container == list:
                if not isinstance(val, list) or not all(map(
                        lambda x: isinstance(x, typ), val)):
                    raise TypeError("%s attribute must be set to an "
                                    "instance of %s" % (key, typ))
            else:
                raise TypeError('Unrecognized container: %s',
                                str(container))
        else:
            if not isinstance(val, typ) and not type(val) == typ:
                raise TypeError("%s attribute must be set to an instance of %s"
                                % (key, typ))
        setattr(self, '__' + str(key), val)
    return property(get, set)


NOPRINT = True


def config(cls):
    new_cls_dict = {}
    vars = []
    for k, v in cls.__dict__.items():
        if isinstance(v, type):
            v = create_pair(k, v)
            vars.append(k)
        elif isinstance(v, tuple) and \
                isinstance(v[0], type) and \
                isinstance(v[1], v[0]):
            v = create_pair(k, v[0], v[1])
            vars.append(k)
        elif isinstance(v, list) and \
                isinstance(v[0], type):
            v = create_pair(k, v[0], container=list)
            vars.append(k)
        elif isinstance(v, tuple) and \
                isinstance(v[0], list) and \
                isinstance(v[0][0], type) and \
                isinstance(v[1], list) and \
                isinstance(v[1][0], v[0][0]):
            v = create_pair(k, v[0][0], v[1][0], container=list)
            vars.append(k)

        new_cls_dict[k] = v
    new_cls_dict['__init__'] = __init__
    new_cls_dict['_vars'] = vars

    return type(cls)(cls.__name__, cls.__bases__, new_cls_dict)


def __init__(self, **kwargs):
    for item in self._vars:
        if item not in kwargs:
            continue
            # eventually log warning
            # log.debug('WARNING %s unset!', item)
        else:
            setattr(self, item, kwargs.get(item))
        getattr(self, item)  # make sure all are set.


def _parse_body(req, **fields):
    try:
        data = tornado.escape.json_decode(req.body)
    except ValueError:
        data = {}
    return data


def _genrand(values, x=10000):
    id = random.randint(0, x)
    while id in values:
        id = random.randint(0, x)
    return id
