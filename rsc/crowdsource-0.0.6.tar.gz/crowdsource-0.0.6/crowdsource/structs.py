import ujson
import pandas
from datetime import datetime
from .competition import CompetitionSpec
from .utils import config


class Struct(object):
    def __init__(self, **kwargs):
        self._fields = {k: v for k, v in kwargs.items()}

    def to_dict(self):
        return self._fields

    def to_json(self):
        return ujson.dumps(self._fields)

    def __repr__(self):
        return self.to_json()


class ClientStruct(Struct):
    def __init__(self, id, **kwargs):
        super(ClientStruct, self).__init__(id=id)
        self.id = id


class CompetitionStruct(Struct):
    def __init__(self, id, clientId, spec, **kwargs):
        self.id = id
        self.clientId = clientId
        self.answer = pandas.DataFrame(ujson.loads(spec.get('answer')))

        # hide answer
        spec['answer'] = ''
        self.spec = CompetitionSpec.from_dict(spec)
        super(CompetitionStruct, self).__init__(id=id, clientId=clientId, spec=spec)


class SubmissionStruct(Struct):
    def __init__(self, id, clientId, competitionId, competition, submission, score, **kwargs):
        self.id = id
        self.clientId = clientId
        self.competitionId = competitionId
        self.competition = competition
        self.score = score
        self.submission = submission
        self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        super(SubmissionStruct, self).__init__(id=id, clientId=clientId, competitionId=competitionId, type=competition.spec.type.value, score=score, timestamp=self.timestamp)
