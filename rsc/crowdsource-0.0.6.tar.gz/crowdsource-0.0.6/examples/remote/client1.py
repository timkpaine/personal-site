import crowdsource.client as ac
from crowdsource.logutils import LOG as log

c = ac.Client('http://csny.herokuapp.com')
c.register()


def foo(competitionSpec, *args, **kwargs):
    log.debug('Answering')

    import pandas
    data = competitionSpec.dataset
    ret = data[data.columns[0]] > kwargs.get('thresh', .5)
    return pandas.DataFrame(ret.astype(int))


def foo1(competitionSpec, *args, **kwargs):
    return foo(competitionSpec, thresh=.2, *args, **kwargs)

c.compete('classify', foo)
c.compete('classify', foo1)
