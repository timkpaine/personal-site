import crowdsource.client as ac
from crowdsource.logutils import LOG as log

c = ac.Client('http://0.0.0.0:8889')
c.register()


def foo(competitionSpec, *args, **kwargs):
    log.debug('Answering')

    import pandas
    data = competitionSpec.dataset
    ret = data[data.columns[0]] > kwargs.get('thresh', .7)
    return pandas.DataFrame(ret.astype(int))


def foo1(competitionSpec, *args, **kwargs):
    import pandas
    # import time
    from sklearn import linear_model
    data = competitionSpec.dataset

    answers = []
    targets = [competitionSpec.target] if competitionSpec.target else competitionSpec.targets

    val = competitionSpec.when
    when = val.timestamp()

    for col in targets:
        reg = linear_model.LinearRegression()
        x = data[col].index.astype(int).values.reshape(len(data[col].index), 1)
        y = data[col].values.reshape(len(data[col]), 1)
        reg.fit(x, y)

        answers.append(reg.predict(when)[0][0])

    answers.append(when)
    return pandas.DataFrame([answers], columns=targets+['when']).set_index(['when'])


c.compete('classify', foo, thresh=.4)
c.compete('predict', foo1)
