import time
import crowdsource.client as ac
from crowdsource.logutils import LOG as log

c = ac.Client('http://0.0.0.0:8889', 1234)
c._sampleClassify()

time.sleep(4)
log.debug(c.leaderboards())

c._sampleClassify()
time.sleep(4)
log.debug(c.leaderboards())
